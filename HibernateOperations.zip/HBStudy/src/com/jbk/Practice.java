package com.jbk;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Practice {

	int id;
	String name;
	String salary;
	
	Practice(){
		System.out.println("I am in practice const");
	}
	
	@Id
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	
	@Override
	public String toString() {
		return "Practice [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	
	
}
