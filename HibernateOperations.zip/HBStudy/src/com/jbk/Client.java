package com.jbk;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client {
	//if we try to load data which is not present in db then load(); method gives exception called "objectNotFoundException".
	
	public static void main(String[] args) {
		

		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Practice.class); 
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		
		//we use load and get method here 
		Practice pp = session.load(Practice.class, 4);	//we need to work here 
		System.out.println(pp);
		session.close();
		
		System.out.println("Data Load Successfully");
		
		
	}
}
