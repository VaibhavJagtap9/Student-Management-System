package com.jbk;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client3 {
		
	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Practice.class); 
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		
		Transaction tr = session.beginTransaction();
		Practice p = new Practice();
		p.setId(12);
		p.setName("Karan");
		p.setSalary("10000");
		session.save(p);	
		tr.commit();
		
		session.close();	
		System.out.println("Data Insert Successfully");
	}
}
