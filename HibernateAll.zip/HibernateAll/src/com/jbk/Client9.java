package com.jbk;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class Client9 {

	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Practice.class); 
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		
		//less than equal to 
		Criteria criteria = session.createCriteria(Practice.class);
		criteria.add(Restrictions.le("salary", "20000"));
		List<Practice> list = criteria.list();
		for(Practice practice : list) {
			System.out.println(practice);
		}	
		
		session.close();

	}

}
