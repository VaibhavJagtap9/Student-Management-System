package com.jbk;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class Client13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Practice.class); 
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		
		//equal to 
		Criteria criteria = session.createCriteria(Practice.class);
		criteria.add(Restrictions.eq("name", "vaibhav"));
		List<Practice> list = criteria.list();
		
		System.out.println(list);
		
		session.close();


	}

}
