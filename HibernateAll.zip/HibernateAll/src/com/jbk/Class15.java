package com.jbk;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Class15 {

	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();
		cfg.configure();
		cfg.addAnnotatedClass(Practice.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		
		session.saveOrUpdate(Practice.class);
		//session.close();
		
		//Practice pp = session.load(Practice.class,3);
		//System.out.println(pp);
		
		//saveOrupdate
		//persist
		//merge   
		
		

	}
}
